/*
 * SWERVE.h
 *
 *  Created on: May 31, 2025
 *      Author: liangnie
 */

#ifndef INC_SWERVE_H_
#define INC_SWERVE_H_
#include "main.h"

void Loop(int16_t Axies[3], int16_t GM6020TurretAngle);

#endif /* INC_SWERVE_H_ */
