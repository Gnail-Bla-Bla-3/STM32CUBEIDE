/*
 * SwerveBuffer.h
 *
 *  Created on: Jun 14, 2025
 *      Author: liangnie
 */

#ifndef INC_SWERVEBUFFER_H_
#define INC_SWERVEBUFFER_H_
#include "main.h"

void AllBufferCalculations(uint16_t bufferValFromPMM, uint8_t shift, int16_t WASDQE[3]);
void AllCheShit2(int16_t allMotors[8]);

#endif /* INC_SWERVEBUFFER_H_ */
