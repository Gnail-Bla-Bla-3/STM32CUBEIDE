/*
 * driving.h
 *
 *  Created on: Jun 6, 2024
 *      Author: liangnie
 */

#ifndef INC_DRIVING_H_
#define INC_DRIVING_H_

#include "main.h"

void allCheShit(int8_t w, int8_t a, int8_t s, int8_t d, int8_t q, int8_t e, int8_t r, int16_t rcRPM[], int8_t chassisVsTurretDrive, float convertedAngle, PID_preset_t chassisPreset);

#endif /* INC_DRIVING_H_ */
